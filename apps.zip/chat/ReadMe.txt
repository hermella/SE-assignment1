++++++this app uses Client-Server Design Pattern+++++++

about the design pattern

*A Client-Server Architecture consists of two types of components: clients and servers.
A server component perpetually listens for requests from client components.
When a request is received, the server processes the request, and then sends a response back to the client. 
*Client/server systems provide access to a central application from one or more remote clients

about demo app

*this application uses socket to implement chat application between a client and a server, i.e a server can send a 
message to the client and the client to server.