/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package decoratorpattern;

/**
 *
 * @author Ajirit
 */
public class Cheese extends pizzaDecorator{

    public final pizza pizza;
    
    public Cheese(pizza pizza){
        this.pizza = pizza;
    }
    @Override
    public String getDesc(){
        return pizza.getDesc() +  ", Cheese (20.72)";
    }
    @Override
    public double getPrice() {
        return pizza.getPrice() + 20.72;
    }
    
}
