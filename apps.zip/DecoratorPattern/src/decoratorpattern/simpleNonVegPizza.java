/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package decoratorpattern;

/**
 *
 * @author Ajirit
 */
public class simpleNonVegPizza implements pizza{

    @Override
    public String getDesc() {
        return "simple non-vegitable pizza (350)";
    }

    @Override
    public double getPrice() {
        return 350;
    }
    
}
