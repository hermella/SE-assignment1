/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package decoratorpattern;

/**
 *
 * @author Ajirit
 */
public class Spinach extends pizzaDecorator{
    private final pizza pizza;
    public Spinach(pizza pizza){
        this.pizza = pizza;
    }
    @Override
    public String getDesc() {
         return pizza.getDesc()+", Spinach (7.92)";
    }
    @Override
    public double getPrice() {
         return pizza.getPrice()+7.92;
    }
}