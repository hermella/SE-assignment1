/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package decoratorpattern;

/**
 *
 * @author Ajirit
 */
public class Ham extends pizzaDecorator{
    private final pizza pizza;
    public Ham(pizza pizza){
        this.pizza = pizza;
    }
    @Override
    public String getDesc() {
        return pizza.getDesc()+", Ham (18.12)";
    }
    @Override
    public double getPrice() {
        return pizza.getPrice()+18.12;
    }
}