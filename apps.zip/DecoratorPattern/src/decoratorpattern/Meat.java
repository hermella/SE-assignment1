/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package decoratorpattern;

/**
 *
 * @author Ajirit
 */
public class Meat extends pizzaDecorator{
    private final pizza pizza;
    public Meat(pizza pizza){
        this.pizza = pizza;
    }
    @Override
    public String getDesc() {
         return pizza.getDesc()+", Meat (14.25)";
    }
    @Override
    public double getPrice() {
        return pizza.getPrice()+14.25;
    }
}