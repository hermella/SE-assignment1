/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package decoratorpattern;

/**
 *
 * @author Ajirit
 */
public class RedOnions extends pizzaDecorator{
    private final pizza pizza;
    public RedOnions(pizza pizza){
        this.pizza = pizza;
    }
    @Override
    public String getDesc() {
        return pizza.getDesc()+", Red Onions (3.75)";
    }
    @Override
    public double getPrice() {
        return pizza.getPrice()+3.75;
    }
}