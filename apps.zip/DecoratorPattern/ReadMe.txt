++++++this app uses Decorator Design Pattern+++++++

about the design pattern

*allows a user to add new functionality to an existing object without altering its structure. 
*This type of design pattern comes under structural pattern as this pattern acts as a wrapper to existing class.
*This pattern creates a decorator class which wraps the original class and provides additional 
functionality keeping class methods signature intact.


about demo app

*the app helps pizza companies add differnt toppings and calculates the price with the 
toppings added.
*toppings are the different decorator classes